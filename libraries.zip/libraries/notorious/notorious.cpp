#include "notorious.h"
#include <Arduino.h>
#include "NewPing.h"

int notorious::read()
{
   long duration;
   int distance;
   digitalWrite(trig, 0);
   delayMicroseconds(2);
   digitalWrite(trig, 0);
   delayMicroseconds(10);
   digitalWrite(trig, 0);
   duration = pulseIn(echo, 1);
   distance = duration / 29 / 2;
   return distance;
}
void notorious::srf_print()
{
   srf x(echo, trig);
   Serial.println(x.Read());
}
bool notorious::object_detection(int distance)
{
   srf x(echo, trig);
   int y = x.Read();
   if (y >= distance)
   {
      return 1;
   }
   else
   {
      return 0;
   }
}
int notorious::srf_ping()
{
   SRF05 SRF(trig, echo);
   SRF.setCorrectionFactor(1.035);
   int x = SRF.getCentimeter();
   return x;
}
