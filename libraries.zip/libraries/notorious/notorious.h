#ifndef notorious_h
#define notorious_h

class notorious
{
   uint8_t echo, trig;

   notorious(int a, int b)
   {
      echo = a;
      trig = b;
      pinMode(trig, OUTPUT);
      pinMode(echo, INPUT);
   }

public:
   int read();
   void srf_print();
   bool object_detection(int distance);
   int srf_ping();
};

#endif