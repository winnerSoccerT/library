#include "king_armin_ultra.h"
void king_ultra::update_ultra_value (int mode=0){
  
      long duration, distanceCm, distanceIn;
      digitalWrite(TRIG_PIN, LOW);
      delayMicroseconds(2);
      digitalWrite(TRIG_PIN, HIGH);
      delayMicroseconds(10);
      digitalWrite(TRIG_PIN, LOW);
      duration = pulseIn(ECHO_PIN, HIGH);
      distanceCm = duration / 29.1 / 2 ;
      distanceIn = duration / 74 / 2;
      out_cm=distanceCm;
      out_inch=distanceIn;
      if (mode == 1) {
        Serial.print(distanceIn);
        Serial.print("in, ");
        Serial.print(distanceCm);
        Serial.print("cm");
        Serial.println();
      }
}