#include "Arduino.h"
class king_ultra {
  public:
    uint8_t TRIG_PIN , ECHO_PIN;
    int out_cm,out_inch;
    king_ultra(const uint8_t trig , const uint8_t echo) {
        TRIG_PIN=trig;
        ECHO_PIN=echo;
       pinMode(trig, OUTPUT);
       pinMode(echo, INPUT);
    }
    void update_ultra_value(int mode=0) ;
};