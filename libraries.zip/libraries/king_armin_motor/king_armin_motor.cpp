#include "king_armin_motor.h"
void king_armin_motor::king_motor_speed (int Speed){
  if(debuger==1){
    Speed=-Speed;
  }
  if(Speed<0){
    digitalWrite(input_pin1,1);
    analogWrite(input_pin2,255+Speed);
  }
  else{
    digitalWrite(input_pin1,0);
    analogWrite(input_pin2,Speed);
  }
}
