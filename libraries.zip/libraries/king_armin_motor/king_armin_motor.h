#include "Arduino.h"
class king_armin_motor{
  private:
   uint8_t input_pin1 , input_pin2 ;
   bool debuger;
  public:
      king_armin_motor(const uint8_t pin1 , const uint8_t pin2 ,bool motor_bug=0){
        input_pin1=pin1;
        input_pin2=pin2;
        debuger=motor_bug;
        pinMode(input_pin1,OUTPUT);
        pinMode(input_pin2,OUTPUT);
      }
      void king_motor_speed (int Speed);

};
