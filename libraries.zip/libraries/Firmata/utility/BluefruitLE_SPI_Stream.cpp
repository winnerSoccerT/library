/*
 * Implementation is in BluefruitLE_SPI_Stream.h to avoid linker issues.
 */
